CS 559 Computer Graphics
UW-Madison
Spring 2018 
Minh Nguyen

This program is a Graphics Town written in WebGL in order to be a foundation for later projects.
Objects implemented are: walking human, house, ground, grass, skybox.
I used simpler shader because object are more complex and not static/ colorless.

Code/Material I used that's not from class website:
Skybox from: http://www.petesoasis.com
CSS from: https://bootswatch.com/cosmo/
Camera view from: https://goo.gl/LqpkLt
Mouse wheel input from: https://goo.gl/dFXdGv


You can control the camera similarly to how you did in my last project. (They seem kinda useless now so please give me your feedback)
You can also control the time of the day and the speed to the walking human.

Things I do that might not be obvious:
- Some textures are made by myself using adobe photoshop.
- World are shifted for better driving experience.
- I used dataurl to make the texture loaded in an synchronous way.


P7 update:
Change a little bit on walking human and drive camera
