  function world() {
    pushMatrix();
    
    translate([0,-5,0])
    //ground
    for (var i = -1; i<=1; i++) {
      for (var j = -1; j<=1; j++) {
        pushMatrix();
        texture = grassTex;
        inColor = [0.45,0.5,0.0];
        translate([i*100,0,j*100]);
        drawGround();
        defaultTex();
        popMatrix();
      }
    }
    inColor = [1.0,1.0,1.0];
        
    //person
    pushMatrix();
    rotateFromPiv([0,0,0],-rad(counter*10),[0,1,0]);
    translate([10,2,0]);
    drawPerson();
    popMatrix();
   

    //house
    for (var i = -3; i<=3; i++) {
      for (var j = -3; j<=3; j++) {
        pushMatrix();
        translate([40*i,7,40*j])
        scale([4,5,3]);
        texture = bricksTex;
        drawHouse();
        defaultTex();
        popMatrix();
        inColor = [1.0,1.0,1.0];

      }
    }
    popMatrix();
  }


  function drawHouse() {
    pushMatrix();

    //walls
    coord = [-1.4,1.4];
    for (var i = 0; i<2; i++) {
      pushMatrix();
      translate([coord[i],0,0]);
      scale([0.3,3,3]);
      createBuffers('cube');
      popMatrix();
    }

    for (var i = 0; i<2; i++) {
      pushMatrix();
      translate([0,0,coord[i]]);
      scale([3,3,0.3])
      createBuffers('cube');
      popMatrix();
    }

    texture = roofTex;
    //roof
    pushMatrix();
    translate([0,2.5,0]);
    scale([3,2,3]);
    createBuffers('pyramid');
    popMatrix();

    //chimney
    pushMatrix();
    translate([1,2.5,0]);
    scale([0.5,2,0.5]);
    createBuffers('cube');
    popMatrix();

    defaultTex();

    inColor=[0.5,0.5,0.5];
    //smoke
    

    popMatrix();
  }



  function drawGround() {
    pushMatrix();

    pushMatrix();
    translate([0,0,0]);
    scale([100,100,100]);
    createBuffers('plane');
    popMatrix();

    popMatrix();
  }



  function drawPerson(speed) {
    pushMatrix();

    //head
    texture = snakeTex;
    pushMatrix();
      translate([0,1.25,0]);
      scale([0.8,0.8,0.8]);
      rotate(rad(130),[0,1,0]);
      createBuffers("sphere");
    popMatrix();

    //body
    texture = checkersTex;
    inColor = [0.5,1.0,1.5];
    pushMatrix();
      translate([0,0,0]);
      scale([1,1.75,0.5]);
      rotate(rad(0),[0,0,0]);
      createBuffers("cube");
    popMatrix();
    inColor = [1.0,1.0,1.0];

    //arms
    texture = checkersTex;
    inColor = [1.25,1.0,0.75];
    coord = [0.75,-0.75];
    var armRot = [rad(30*Math.sin(counter*0.8)), rad(-30*Math.sin(counter*0.8))]
    for (var i = 0; i<coord.length; i++) {
      pushMatrix();
        mat4.translate(Tmodel,Tmodel,[coord[i],0.75,0]);
        rotateFromPiv([0,-0.75,0], -armRot[i],[1,0,0]);
        mat4.scale(Tmodel,Tmodel,[0.5,1.75,0.5]);
        createBuffers("cube")
      popMatrix();
    }

    //legs
    coord = [0.25,-0.25];
    var legRot = [rad(50*Math.sin(counter*0.8)), rad(-50*Math.sin(counter*0.8))]
    for (var i = 0; i<coord.length; i++) {
      pushMatrix();
        mat4.translate(Tmodel,Tmodel,[coord[i],-0.75,0]);
        rotateFromPiv([0,-0.75,0], legRot[i],[1,0,0]);
        mat4.scale(Tmodel,Tmodel,[0.5,1.5,0.5]);
        createBuffers("cube")
      popMatrix();
    }

    inColor = [1.0,1.0,1.0];
    popMatrix();
  }

function createBuffers(block, sky) {
    switch (block) {
      case "truncatedCone":
        buffers = truncatedConeBuffer;
        break;
      case "torus":
        buffers = torusBuffer;
        break;
      case "plane":
        buffers = planeBuffer;
        break;
      case "cresent":
        buffers = cresentBuffer;
        break;
      case "disc":
        buffers = discBuffer;
        break;
      case "sphere":
        buffers = sphereBuffer;
        break;
      case "skyBox":
        buffers = skyBoxBuffer;
        break;
      case "cube":
        buffers = cubeBuffer;
        break;
      case "cylinder":
        buffers = cylinderBuffer;
        break;
      case "pyramid":
        buffers = pyramidBuffer;
        break;
      case "octagon":
        buffers = octagonBuffer;
        break;
      case "diamond":
        buffers = diamondBuffer;
        break;
    }


    var skyBox = sky || 0.0;
    Tmc = m4.multiply(Tmodel,Tcamera);
    Tmcp = m4.multiply(Tmc,Tprojection);
    twgl.setUniforms(shaders,{transf : Tmcp,
                               normalMatrix:m4.transpose(m4.inverse(Tmodel)),
                                 time:counter*10,
                                   patttern:play,
                                         inColor:inColor,
                                             day:sliderDay.value,
                                               tex: texture,
                                                skyBox: skyBox,});
    twgl.setBuffersAndAttributes(gl,shaders,buffers);
    twgl.drawBufferInfo(gl, gl.TRIANGLES, buffers);
  }
